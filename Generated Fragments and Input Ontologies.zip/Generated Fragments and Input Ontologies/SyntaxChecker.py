#!/usr/bin/env python3
"""
Recursively validates all .ttl (Turtle) files in a directory structure.
"""

import os
from pathlib import Path
from rdflib import Graph
from rdflib.exceptions import ParserError
from typing import Tuple, List


def validate_ttl_file(file_path: Path) -> Tuple[bool, str]:
    """
    Validate a single Turtle file.
    
    Args:
        file_path: Path to the .ttl file
        
    Returns:
        Tuple of (is_valid, error_message)
    """
    try:
        g = Graph()
        g.parse(file_path, format='turtle')
        return True, ""
    except ParserError as e:
        return False, f"Parser error: {str(e)}"
    except Exception as e:
        return False, f"Error: {str(e)}"


def find_and_validate_ttl_files(root_dir: str = '.') -> None:
    """
    Recursively find and validate all .ttl files in the directory structure.
    
    Args:
        root_dir: Root directory to start searching (default: current directory)
    """
    root_path = Path(root_dir).resolve()
    
    print(f"{'='*80}")
    print(f"Turtle File Validation Report")
    print(f"{'='*80}")
    print(f"Searching in: {root_path}\n")
    
    # Find all .ttl files recursively
    ttl_files = list(root_path.rglob('*.ttl'))
    
    if not ttl_files:
        print("No .ttl files found in the directory structure.")
        return
    
    print(f"Found {len(ttl_files)} .ttl file(s)\n")
    print(f"{'-'*80}\n")
    
    valid_files: List[Path] = []
    invalid_files: List[Tuple[Path, str]] = []
    
    # Validate each file
    for file_path in sorted(ttl_files):
        relative_path = file_path.relative_to(root_path)
        print(f"Checking: {relative_path}")
        
        is_valid, error_msg = validate_ttl_file(file_path)
        
        if is_valid:
            print(f"  ✓ Valid Turtle syntax")
            valid_files.append(file_path)
        else:
            print(f"  ✗ Invalid Turtle syntax")
            print(f"    {error_msg}")
            invalid_files.append((file_path, error_msg))
        
        print()
    
    # Summary
    print(f"{'-'*80}")
    print(f"SUMMARY")
    print(f"{'-'*80}")
    print(f"Total files checked: {len(ttl_files)}")
    print(f"Valid files:         {len(valid_files)} ({len(valid_files)/len(ttl_files)*100:.1f}%)")
    print(f"Invalid files:       {len(invalid_files)} ({len(invalid_files)/len(ttl_files)*100:.1f}%)")
    print(f"{'='*80}")
    
    # List invalid files if any
    if invalid_files:
        print(f"\nINVALID FILES:")
        for file_path, error in invalid_files:
            relative_path = file_path.relative_to(root_path)
            print(f"  - {relative_path}")
            print(f"    Error: {error}")


if __name__ == "__main__":
    import sys
    
    # Allow specifying a directory as command line argument
    directory = sys.argv[1] if len(sys.argv) > 1 else '.'
    
    try:
        find_and_validate_ttl_files(directory)
    except KeyboardInterrupt:
        print("\n\nValidation interrupted by user.")
        sys.exit(1)
    except Exception as e:
        print(f"\nUnexpected error: {e}")
        sys.exit(1)